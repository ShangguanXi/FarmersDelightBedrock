export const vanillaCookingPotRecipe = {
    "recipe": [
        {
            'identifer': 'farmersdelight:bone_broth',
            'tags': ['cooking_pot'],
            'priority': 0,
            "time": 200,
            "container": {
                "item": "minecraft:bowl"
            },
            "ingredients": [
                {
                    "item": "minecraft:red_mushroom"
                },
                {
                    "item": "minecraft:bone"
                }
            ],
            "result": {
                "item": "farmersdelight:bone_broth"
            }
        },
        {
            'identifer': 'farmersdelight:glow_berry_custard',
            'tags': ['cooking_pot'],
            'priority': 0,
            "time": 200,
            "ingredients": [
                {
                    "item": "farmersdelight:milk_bottle"
                },
                {
                    "item": "minecraft:glow_berries"
                },
                {
                    "tag": "minecraft:egg"
                },
                {
                    "item": "minecraft:sugar"
                }
            ],
            "result": {
                "item": "farmersdelight:glow_berry_custard"
            }
        },
        {
            'identifer': 'farmersdelight:apple_cider',
            'tags': ['cooking_pot'],
            'priority': 0,
            "time": 200,
            "container": {
                "item": "minecraft:glass_bottle"
            },
            "ingredients": [
                {
                    "item": "minecraft:apple"
                },
                {
                    "item": "minecraft:apple"
                },
                {
                    "item": "minecraft:sugar"
                }
            ],
            "result": {
                "item": "farmersdelight:apple_cider"
            }
        },
        {
            'identifer': 'farmersdelight:hot_cocoa',
            'tags': ['cooking_pot'],
            'priority': 0,
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                {
                    "item": "minecraft:cocoa_beans"
                },
                {
                    "item": "minecraft:cocoa_beans"
                },
                {
                    "item": "minecraft:sugar"
                },
                {
                    "item": "farmersdelight:milk_bottle"
                }
            ],
            "recipe_book_tab": "drinks",
            "result": {
                "item": "farmersdelight:hot_cocoa"
            }
        },
        {
            'identifer': 'farmersdelight:dumplings',
            'tags': ['cooking_pot'],
            'priority': 0,
            "type": "farmersdelight:cooking",
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                [
                    { "item": "minecraft:porkchop" },
                    { "item": "better_on_bedrock:beef_patty_raw" },
                    { "item": "minecraft:beef" },
                    { "item": "minecraft:chicken" },
                    { "item": "minecraft:brown_mushroom" },
                    { "tag": "farmersdelight:is_raw_porkchop" },
                    { "tag": "farmersdelight:is_raw_chicken" },
                    { "tag": "farmersdelight:is_raw_beef" }
                ],
                [{ "tag": "farmersdelight:is_cabbage" },
                    { "item": "better_on_bedrock:gabage_leaves" }],
                [
                    {
                        "tag": "farmersdelight:is_onion"
                    },
                    { "item": "better_on_bedrock:onion" }
                ],
                [{
                        "tag": "farmersdelight:is_dough"
                    },
                    {
                        "item": "better_on_bedrock:dough"
                    }
                ]
            ],
            "recipe_book_tab": "misc",
            "result": {
                "item": "farmersdelight:dumplings",
                "count": 2
            }
        },
        {
            'identifer': 'farmersdelight:cooked_rice',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                {
                    "tag": "farmersdelight:is_rice"
                }
            ],
            "recipe_book_tab": "misc",
            "result": {
                "item": "farmersdelight:cooked_rice"
            }
        },
        {
            'identifer': 'farmersdelight:beef_stew',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                [
                    { "tag": "farmersdelight:is_raw_beef" },
                    { "item": "minecraft:beef" },
                    { "item": "better_on_bedrock:beef_patty_raw" }
                ],
                {
                    "item": "minecraft:carrot"
                },
                {
                    "item": "minecraft:potato"
                }
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:beef_stew"
            }
        },
        {
            'identifer': 'farmersdelight:onion_soup',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                [
                    { "tag": "farmersdelight:is_onion" },
                    { "item": "better_on_bedrock:onion" }
                ],
                [
                    { "tag": "farmersdelight:is_onion" },
                    { "item": "better_on_bedrock:onion" }
                ],
                {
                    "item": "minecraft:bread"
                },
                {
                    "tag": "farmersdelight:is_milk"
                }
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:onion_soup"
            }
        },
        {
            'identifer': 'farmersdelight:chicken_soup',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                [
                    { "tag": "farmersdelight:is_raw_chicken" },
                    { "item": "minecraft:chicken" }
                ],
                [{
                        "tag": "farmersdelight:is_cabbage"
                    },
                    { "item": "better_on_bedrock:gabage_leaves" }],
                {
                    "item": "minecraft:carrot"
                },
                [
                    { "item": "minecraft:carrot" },
                    { "item": "minecraft:potato" },
                    { "item": "minecraft:beetroot" },
                    { "tag": "farmersdelight:is_onion" },
                    { "item": "better_on_bedrock:onion" },
                    { "tag": "farmersdelight:is_tomato" },
                    { "item": "better_on_bedrock:tomato_seed" }
                ]
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:chicken_soup"
            }
        },
        {
            'identifer': 'farmersdelight:vegetable_soup',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                [{
                        "tag": "farmersdelight:is_cabbage"
                    },
                    { "item": "better_on_bedrock:gabage_leaves" }],
                {
                    "item": "minecraft:beetroot"
                },
                {
                    "item": "minecraft:potato"
                },
                {
                    "item": "minecraft:carrot"
                }
            ],
            "recipe_book_tab": "misc",
            "result": {
                "item": "farmersdelight:vegetable_soup"
            }
        },
        {
            'identifer': 'farmersdelight:fish_stew',
            'tags': ['cooking_pot'],
            'priority': 0,
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                [
                    { "tag": "farmersdelight:is_raw_fish" },
                    { "item": "minecraft:salmon" },
                    { "item": "minecraft:cod" }
                ],
                [{
                        "tag": "farmersdelight:is_onion"
                    },
                    { "item": "better_on_bedrock:onion" }],
                {
                    "item": "farmersdelight:tomato_sauce"
                }
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:fish_stew"
            }
        },
        {
            'identifer': 'farmersdelight:fried_rice',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                {
                    "tag": "farmersdelight:is_rice"
                },
                {
                    "tag": "minecraft:egg"
                },
                [{
                        "tag": "farmersdelight:is_onion"
                    },
                    { "item": "better_on_bedrock:onion" }],
                {
                    "item": "minecraft:carrot"
                }
            ],
            "recipe_book_tab": "misc",
            "result": {
                "item": "farmersdelight:fried_rice"
            }
        },
        {
            'identifer': 'farmersdelight:pumpkin_soup',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                [{
                        "tag": "farmersdelight:is_cabbage"
                    },
                    { "item": "better_on_bedrock:gabage_leaves" }],
                {
                    "item": "farmersdelight:pumpkin_slice"
                },
                {
                    "tag": "farmersdelight:is_milk"
                },
                [
                    { "tag": "farmersdelight:is_raw_porkchop" },
                    { "item": "minecraft:porkchop" }
                ],
            ],
            "recipe_book_tab": "misc",
            "result": {
                "item": "farmersdelight:pumpkin_soup"
            }
        },
        {
            'identifer': 'farmersdelight:tomato_sauce',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                [
                    { "tag": "farmersdelight:is_tomato" },
                    { "item": "better_on_bedrock:tomato_seed" }
                ],
                [
                    { "tag": "farmersdelight:is_tomato" },
                    { "item": "better_on_bedrock:tomato_seed" }
                ]
            ],
            "result": {
                "item": "farmersdelight:tomato_sauce"
            }
        },
        {
            'identifer': 'farmersdelight:baked_cod_stew',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                [{
                        "tag": "farmersdelight:is_cabbage"
                    },
                    { "item": "better_on_bedrock:gabage_leaves" }],
                {
                    "tag": "minecraft:egg"
                },
                [
                    { "item": "minecraft:cod" },
                    { "tag": "farmersdelight:cod_slice" }
                ],
                [{
                        "tag": "farmersdelight:is_tomato"
                    },
                    { "item": "better_on_bedrock:tomato_seed" }],
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:baked_cod_stew"
            }
        },
        {
            'identifer': 'farmersdelight:pasta_with_meatballs',
            'tags': ['cooking_pot'],
            'priority': 0,
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                {
                    "item": "farmersdelight:tomato_sauce"
                },
                [
                    { "item": "better_on_bedrock:beef_patty_raw" },
                    {
                        "item": "farmersdelight:minced_beef"
                    }
                ],
                {
                    "tag": "farmersdelight:is_pasta"
                },
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:pasta_with_meatballs"
            }
        },
        {
            'identifer': 'farmersdelight:pasta_with_mutton_chop',
            'tags': ['cooking_pot'],
            'priority': 0,
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                [
                    {
                        "item": "minecraft:mutton"
                    },
                    {
                        "tag": "farmersdelight:is_raw_mutton"
                    },
                    { "item": "better_on_bedrock:raw_mutton_chops" }
                ],
                {
                    "item": "farmersdelight:tomato_sauce"
                },
                {
                    "tag": "farmersdelight:is_pasta"
                },
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:pasta_with_mutton_chop"
            }
        },
        {
            'identifer': 'farmersdelight:vegetable_noodles',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                [{
                        "tag": "farmersdelight:is_cabbage"
                    },
                    { "item": "better_on_bedrock:gabage_leaves" }],
                {
                    "item": "minecraft:brown_mushroom"
                },
                {
                    "item": "minecraft:carrot"
                },
                {
                    "item": "farmersdelight:raw_pasta"
                },
                [
                    { "item": "minecraft:carrot" },
                    { "item": "minecraft:potato" },
                    { "item": "minecraft:beetroot" },
                    { "tag": "farmersdelight:is_onion" },
                    { "item": "better_on_bedrock:onion" },
                    { "tag": "farmersdelight:is_tomato" },
                    { "item": "better_on_bedrock:tomato_seed" }
                ]
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:vegetable_noodles"
            }
        },
        {
            'identifer': 'farmersdelight:squid_ink_pasta',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                {
                    "tag": "farmersdelight:is_pasta"
                },
                [{
                        "tag": "farmersdelight:is_tomato"
                    },
                    { "item": "better_on_bedrock:tomato_seed" }],
                {
                    "item": "minecraft:ink_sac"
                },
                [
                    { "item": "minecraft:cod" },
                    { "tag": "farmersdelight:is_raw_fish" },
                    { "tag": "minecraft:salmon" }
                ]
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:squid_ink_pasta"
            }
        },
        {
            'identifer': 'farmersdelight:stuffed_pumpkin_block_item',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:pumpkin"
            },
            "time": 200,
            "experience": 2.0,
            "ingredients": [
                {
                    "tag": "farmersdelight:is_rice"
                },
                [{
                        "tag": "farmersdelight:is_onion"
                    },
                    { "item": "better_on_bedrock:onion" }],
                {
                    "item": "minecraft:brown_mushroom"
                },
                {
                    "item": "minecraft:potato"
                },
                {
                    "item": "minecraft:sweet_berries"
                },
                [
                    { "item": "minecraft:carrot" },
                    { "item": "minecraft:potato" },
                    { "item": "minecraft:beetroot" },
                    { "tag": "farmersdelight:is_onion" },
                    { "item": "better_on_bedrock:onion" },
                    { "tag": "farmersdelight:is_cabbage" },
                    { "item": "better_on_bedrock:gabage_leaves" },
                    { "tag": "farmersdelight:is_tomato" },
                    { "item": "better_on_bedrock:tomato_seed" }
                ]
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:stuffed_pumpkin_block_item"
            }
        },
        {
            'identifer': 'farmersdelight:rabbit_stew',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                {
                    "item": "minecraft:baked_potato"
                },
                {
                    "item": "minecraft:rabbit"
                },
                {
                    "item": "minecraft:carrot"
                },
                [
                    {
                        "item": "minecraft:brown_mushroom"
                    },
                    {
                        "item": "minecraft:red_mushroom"
                    }
                ]
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "minecraft:rabbit_stew"
            }
        },
        {
            'identifer': 'farmersdelight:cabbage_rolls',
            'tags': ['cooking_pot'],
            'priority': 0,
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                [
                    {
                        "tag": "farmersdelight:cabbage_roll_ingredients"
                    },
                    {
                        "item": "minecraft:porkchop"
                    },
                    {
                        "item": "minecraft:carrot"
                    },
                    {
                        "item": "minecraft:potato"
                    },
                    {
                        "item": "minecraft:beetroot"
                    },
                    {
                        "item": "minecraft:brown_mushroom"
                    },
                    {
                        "item": "minecraft:red_mushroom"
                    },
                    {
                        "tag": "minecraft:egg"
                    },
                    { "item": "better_on_bedrock:beef_patty_raw" },
                    {
                        "item": "minecraft:beef"
                    },
                    {
                        "item": "minecraft:chicken"
                    },
                    {
                        "item": "minecraft:salmon"
                    },
                    {
                        "item": "minecraft:cod"
                    }
                ],
                [{
                        "tag": "farmersdelight:is_cabbage"
                    },
                    { "item": "better_on_bedrock:gabage_leaves" }]
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:cabbage_rolls"
            }
        },
        {
            'identifer': 'farmersdelight:noodle_soup',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                {
                    "tag": "farmersdelight:is_pasta"
                },
                {
                    "tag": "farmersdelight:is_cooked_egg"
                },
                {
                    "item": "minecraft:dried_kelp"
                },
                [
                    {
                        "tag": "farmersdelight:is_raw_porkchop"
                    },
                    {
                        "item": "minecraft:porkchop"
                    }
                ]
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:noodle_soup"
            }
        },
        {
            'identifer': 'farmersdelight:dog_food',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                {
                    "tag": "farmersdelight:is_rice"
                },
                {
                    "item": "minecraft:bone_meal"
                },
                {
                    "item": "minecraft:rotten_flesh"
                },
                [
                    {
                        "tag": "farmersdelight:wolf_prey"
                    },
                    {
                        "item": "minecraft:chicken"
                    },
                    {
                        "item": "minecraft:mutton"
                    },
                    { "item": "better_on_bedrock:raw_mutton_chops" }
                ]
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:dog_food"
            }
        },
        {
            'identifer': 'farmersdelight:mushroom_rice',
            'tags': ['cooking_pot'],
            'priority': 0,
            "container": {
                "item": "minecraft:bowl"
            },
            "time": 200,
            "experience": 1.0,
            "ingredients": [
                {
                    "item": "minecraft:brown_mushroom"
                },
                {
                    "item": "minecraft:red_mushroom"
                },
                {
                    "item": "minecraft:carrot"
                },
                {
                    "item": "farmersdelight:rice"
                }
            ],
            "recipe_book_tab": "meals",
            "result": {
                "item": "farmersdelight:mushroom_rice"
            }
        }
    ]
};
