import {
    Block,
    BlockComponentPlayerInteractEvent,
    BlockComponentRandomTickEvent,
    BlockCustomComponent,
    BlockPermutation,
    BlockVolume,
    Container,
    EntityInventoryComponent,
    Player,
    StartupEvent,
    system,
    Vector3,
} from "@minecraft/server";
import { takeItem } from "../../lib/ItemUtil";
import { CropsComponentParams } from "./CropComponent";
import { subscribeEvent } from "../../lib/EventSubscriber";
import { resolveSpec } from "../../lib/ObjectUtil";

function handlePlanting(seedId: string, crop: string, topLocation: Vector3, container: Container, player: Player, block: Block) {
    if (!player) return;
    if (!container) return;
    const selectedSlot = container?.getSlot(player.selectedSlotIndex)
    const itemId = selectedSlot?.typeId;
    if (itemId == seedId) {
        player.dimension.playSound("dig.grass", block.location);
        block.dimension.setBlockType(topLocation, crop);
        takeItem(container, player.selectedSlotIndex, 1);
    }
    return
}
class RichSoilFarmlandComponent implements BlockCustomComponent {
    constructor() {
        this.onRandomTick = this.onRandomTick.bind(this);
        this.onPlayerInteract = this.onPlayerInteract.bind(this);

    }
    onPlayerInteract(args: BlockComponentPlayerInteractEvent): void {
        const player = args.player;
        const face = args.face;
        const inventory = player?.getComponent("inventory") as EntityInventoryComponent;
        const container = inventory?.container;
        const block = args.block;
        const dimension = args.dimension;
        if (!player) return;
        if (!container) return;
        const selectedSlot = container?.getSlot(player.selectedSlotIndex)
        const itemStack = selectedSlot.getItem()
        if (!itemStack) return
        const topLocation = { x: block.location.x, y: block.location.y + 1, z: block.location.z }
        const topBlockId = dimension.getBlock(topLocation)?.typeId
        if (face == 'Up' && topBlockId == "minecraft:air") {
            handlePlanting("minecraft:wheat_seeds", "farmersdelight:rich_soil_wheat", topLocation, container, player, block)
            handlePlanting("minecraft:potato", "farmersdelight:rich_soil_potato", topLocation, container, player, block)
            handlePlanting("minecraft:carrot", "farmersdelight:rich_soil_carrot", topLocation, container, player, block)
            handlePlanting("minecraft:beetroot_seeds", "farmersdelight:rich_soil_beetroot", topLocation, container, player, block)
            handlePlanting("minecraft:torchflower_seeds", "farmersdelight:rich_soil_torchflower_crop", topLocation, container, player, block)
            handlePlanting("minecraft:torchflower", "farmersdelight:rich_soil_torchflower", topLocation, container, player, block)
            const crop = resolveSpec<string>(itemStack, "farmersdelight:seed");
            if (crop) {
                handlePlanting(itemStack.typeId, crop, topLocation, container, player, block)
            }
        }

    }
    onRandomTick(args: BlockComponentRandomTickEvent): void {

        const block = args.block;
        if (block?.typeId !== "farmersdelight:rich_soil_farmland") return;

        const { x, y, z } = block.location;
        const dimension = block.dimension;
        const fromLocation = { x: x - 4, y: y, z: z - 4 };
        const toLocation = { x: x + 4, y: y + 1, z: z + 4 };
        const detectLocs = new BlockVolume(fromLocation, toLocation).getBlockLocationIterator();
        const moisturizedAmount = block.permutation.getState('farmersdelight:moisturized_amount') as number;
        let hasWater = false;
        for (const location of detectLocs) {
            const water = dimension.getBlock(location)?.typeId === "minecraft:water";
            if (water) {
                hasWater = true;
                break;
            }
        };
        if (hasWater) {
            if (moisturizedAmount < 7) block.setPermutation(block.permutation.withState('farmersdelight:moisturized_amount', moisturizedAmount + 1));
        } else {
            if (moisturizedAmount > 0) {
                block.setPermutation(block.permutation.withState('farmersdelight:moisturized_amount', moisturizedAmount - 1));
            } else {
                block.setPermutation(BlockPermutation.resolve('farmersdelight:rich_soil'));
            }
        };
        const cropBlock = dimension.getBlock({ x: x, y: y + 1, z: z });
        if (!cropBlock) return
        const params = resolveSpec<CropsComponentParams>(cropBlock, "farmersdelight:crop");
        if (!params) return;
        const growth: number = cropBlock.permutation.getState(params.state.name) as number;
        if (growth < params.state.age) {
            cropBlock.setPermutation(cropBlock.permutation.withState(params.state.name, growth + 1));
            dimension.spawnParticle("minecraft:crop_growth_emitter", { x: block.location.x + 0.5, y: block.location.y + 1.5, z: block.location.z + 0.5 })
            
        }


    }
}
export class RichSoilFarmlandComponentRegister {
    @subscribeEvent(system.beforeEvents.startup)
    register(args: StartupEvent) {
        args.blockComponentRegistry.registerCustomComponent('farmersdelight:rich_soil_farmland', new RichSoilFarmlandComponent());
    }

}
